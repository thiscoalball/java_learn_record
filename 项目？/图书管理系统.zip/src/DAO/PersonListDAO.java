package DAO;

import domain.PersonList;

public class PersonListDAO extends BasicDAO<PersonList>{
}
