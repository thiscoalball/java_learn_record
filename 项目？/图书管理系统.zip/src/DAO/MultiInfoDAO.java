package DAO;

import domain.MultiInfoBean;

public class MultiInfoDAO extends BasicDAO<MultiInfoBean> {

}
