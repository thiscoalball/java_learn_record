package DAO;

import domain.BorrowList;

public class BorrowListDAO extends BasicDAO<BorrowList> {
}
