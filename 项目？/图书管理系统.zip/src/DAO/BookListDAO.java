package DAO;

import domain.BookList;

public class BookListDAO extends BasicDAO<BookList> {
}
